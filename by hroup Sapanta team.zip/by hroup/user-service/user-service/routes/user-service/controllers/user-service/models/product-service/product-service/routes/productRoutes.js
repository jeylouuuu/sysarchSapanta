const express = require('express');
const { listProducts, addProduct, getProductDetails } = require('../controllers/productController');
const router = express.Router();

router.get('/', listProducts);
router.post('/', addProduct);
router.get('/:id', getProductDetails);

module.exports = router;
