const express = require('express');
const { placeOrder, getOrderStatus } = require('../controllers/orderController');
const router = express.Router();

router.post('/', placeOrder);
router.get('/:id', getOrderStatus);

module.exports = router;