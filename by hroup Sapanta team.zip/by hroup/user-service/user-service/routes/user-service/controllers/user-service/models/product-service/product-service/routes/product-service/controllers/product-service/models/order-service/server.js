const express = require('express');
const mongoose = require('mongoose');
const orderRoutes = require('./routes/orderRoutes');
require('dotenv').config();

const app = express();
app.use(express.json());

mongoose.connect(process.env.MONGO_URI_ORDER)
  .then(() => console.log('Order Service DB connected'))
  .catch(err => console.error(err));

app.use('/api/orders', orderRoutes);

const PORT = process.env.PORT_ORDER || 5003;
app.listen(PORT, () => console.log(`Order Service running on port ${PORT}`));