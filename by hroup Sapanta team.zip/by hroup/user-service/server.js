const express = require('express');
const mongoose = require('mongoose');
const userRoutes = require('./routes/userRoutes');
require('dotenv').config();

const app = express();
app.use(express.json());

mongoose.connect(process.env.MONGO_URI_USER)
  .then(() => console.log('User Service DB connected'))
  .catch(err => console.error(err));

app.use('/api/users', userRoutes);

const PORT = process.env.PORT_USER || 5001;
app.listen(PORT, () => console.log(`User Service running on port ${PORT}`));