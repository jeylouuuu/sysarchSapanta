// Import required modules
const express = require("express");
const { ApolloServer, gql } = require("apollo-server-express");
const cors = require("cors");

// Initialize Express app
const app = express();
app.use(cors());

// Sample in-memory data (temporary database)
const movies = [
  { id: "1", title: "Inception", director: "Christopher Nolan", releaseYear: 2010 },
  { id: "2", title: "Interstellar", director: "Christopher Nolan", releaseYear: 2014 }
];

// Define GraphQL schema using gql template literal
const typeDefs = gql`
  type Movie {
    id: ID!
    title: String!
    director: String!
    releaseYear: Int!
  }
  type Query {
    getMovies: [Movie]
    getMovie(id: ID!): Movie
  }
  type Mutation {
    addMovie(title: String!, director: String!, releaseYear: Int!): Movie
  }
`;

// Define resolvers to handle GraphQL queries and mutations
const resolvers = {
  Query: {
    getMovies: () => movies, // Return all movies
    getMovie: (_, { id }) => movies.find(movie => movie.id === id) // Find a movie by ID
  },
  Mutation: {
    addMovie: (_, { title, director, releaseYear }) => {
      const newMovie = { id: String(movies.length + 1), title, director, releaseYear };
      movies.push(newMovie); // Add new movie to the list
      return newMovie;
    }
  }
};

// Initialize Apollo Server with type definitions and resolvers
const server = new ApolloServer({ typeDefs, resolvers });

// Start the server
async function startServer() {
  await server.start(); // Ensure Apollo Server is started before applying middleware
  server.applyMiddleware({ app });
  app.listen(4000, () => {
    console.log("✅ Server running at http://localhost:4000/graphql");
  });
}

startServer();
